<?php
$pdo = new PDO(
    "mysql:host=sql210.infinityfree.com;dbname=if0_43174277_joyvet;charset=utf8mb4",
    "if0_43174277",
    "CV9vR8fr3K9L",
    [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
    ]
);
?>